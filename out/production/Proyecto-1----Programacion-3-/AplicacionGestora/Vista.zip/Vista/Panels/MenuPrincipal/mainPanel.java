package AplicacionGestora.Vista.Panels.MenuPrincipal;

import javax.swing.*;
import java.awt.*;

public class mainPanel extends JFrame {
    private CardLayout gestorViews;
    private JPanel contentPanel;
    private SelectionPanel panelInicial;

    private void createUIComponents (){
        panelInicial = new SelectionPanel(this);
    }

    public mainPanel () {
        //propiedades de la ventana
        setTitle("Panel principal de gestion de restaurante");
        setSize(700,700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout( new BorderLayout(10,10));

        //inicializamos los contenidos
        setContentPane (contentPanel );
        gestorViews = new CardLayout();
        contentPanel = new JPanel(gestorViews);

        contentPanel.add  (panelInicial, "Pantalla de inicio");
        gestorViews.show(contentPanel, "Pantalla inicia;");
    } //end mainPanel

    public void mostrarMenuAdmin() {
        // Se instancia el menú solo cuando el usuario elige este rol
        //MenuAdmin menuAdmin = new MenuAdmin();
        //panelContenedor.add(menuAdmin, "VistaAdmin");
        //gestorVistas.show(panelContenedor, "VistaAdmin");
    }

    public void mostrarMenuCliente() {
        // Se instancia el menú solo cuando el usuario elige este rol
        //MenuCliente menuCliente = new MenuCliente();
        //panelContenedor.add(menuCliente, "VistaCliente");
       // gestorVistas.show(panelContenedor, "VistaCliente");
    }

} //end class




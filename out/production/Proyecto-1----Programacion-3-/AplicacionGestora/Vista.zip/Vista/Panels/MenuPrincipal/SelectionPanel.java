package AplicacionGestora.Vista.Panels.MenuPrincipal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SelectionPanel extends JPanel {

    public SelectionPanel (mainPanel main) {
        setLayout(new GridLayout(1,2,20,20));

        JButton btnAdmin = new JButton("Entrar como admin");
        JButton btnRegular = new JButton("Entrar como usuario regular");

        btnAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                main.mostrarMenuAdmin();
            }
        });

        btnRegular.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                main.mostrarMenuCliente();
            }
        });
        add (btnAdmin);
        add (btnRegular);
    }
}
